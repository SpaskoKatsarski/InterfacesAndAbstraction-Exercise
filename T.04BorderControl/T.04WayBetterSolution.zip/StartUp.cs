﻿using System;
using System.Collections.Generic;

namespace BorderControl
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            List<IIdentifiable> species = new List<IIdentifiable>();

            string input;
            while ((input = Console.ReadLine()) != "End")
            {
                string[] specieInfo = input
                    .Split(' ', StringSplitOptions.RemoveEmptyEntries);

                if (specieInfo.Length == 3)
                {
                    //Citizen
                    species.Add(new Citizen(specieInfo[0], int.Parse(specieInfo[1]), specieInfo[2]));
                }
                else if (specieInfo.Length == 2)
                {
                    //Robot
                    species.Add(new Robot(specieInfo[0], specieInfo[1]));
                }
            }

            string detainingDigits = Console.ReadLine();

            foreach (var specie in species)
            {
                if (specie.Id.EndsWith(detainingDigits))
                {
                    Console.WriteLine(specie.Id);
                }
            }
        }
    }
}
