﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public class Pet : ISpecie
    {
        public Pet(string name, string birthdate)
        {
            this.Name = name;
            this.Birthdate = birthdate;
        }

        public string Name {get; private set; }

        public string Model => throw new NotImplementedException();

        public string Id => throw new NotImplementedException();

        public int Age => throw new NotImplementedException();

        public string Birthdate { get; private set; }
    }
}
