﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public class Robot : IRobot
    {
        public Robot(string model, string id)
        {
            this.Model = model;
            this.Id = id;
            this.Birthdate = "x";
        }

        public string Model { get; private set; }

        public string Id { get; private set; }

        public string Name => throw new NullReferenceException();

        public int Age => throw new NullReferenceException();

        public string Birthdate { get; private set; }
    }
}
