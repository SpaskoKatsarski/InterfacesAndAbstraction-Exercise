﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BorderControl
{
    public interface ISpecie
    {
        string Name { get; }

        string Model { get; }

        string Id { get; }

        int Age { get; }

        string Birthdate { get; }
    }
}
