﻿using System;
using System.Collections.Generic;

namespace BorderControl
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            List<ISpecie> species = new List<ISpecie>();

            string input;
            while ((input = Console.ReadLine()) != "End")
            {
                string[] specieInfo = input
                    .Split(' ', StringSplitOptions.RemoveEmptyEntries);

                if (specieInfo[0] == "Citizen")
                {
                    //Citizen
                    species.Add(new Citizen(specieInfo[1], int.Parse(specieInfo[2]), specieInfo[3], specieInfo[4]));
                }
                else if (specieInfo[0] == "Robot")
                {
                    //Robot
                    species.Add(new Robot(specieInfo[0], specieInfo[1]));
                }
                else if (specieInfo[0] == "Pet")
                {
                    species.Add(new Pet(specieInfo[1], specieInfo[2]));
                }
            }

            string year = Console.ReadLine();

            foreach (var specie in species)
            {
                if (specie.Birthdate.EndsWith(year))
                {
                    Console.WriteLine(specie.Birthdate);
                }
            }
        }
    }
}
